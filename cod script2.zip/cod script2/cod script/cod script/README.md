# hobrtEcom
hobrt eCommerce script 

# how to install
first create a database in you cpanel
upload all files to your root path or any subroot path you want 

than go to 

yourdomain.com/install/install.php

check all required files/folders is writable if not just go to the file and change permmisions to 777

than click to start installation

step 1 fill all your database info

step 2 enter your admin info

step 3 enter your store title

and after the installation is done please delete install folder and enjoy ;)
